package com.ejerciciounospring.ejerciciounospring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjerciciounospringApplicationTests {

	@Test
	void contextLoads() {
	}

}
