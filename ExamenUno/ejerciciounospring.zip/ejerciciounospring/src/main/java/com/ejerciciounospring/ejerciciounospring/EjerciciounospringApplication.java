package com.ejerciciounospring.ejerciciounospring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjerciciounospringApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjerciciounospringApplication.class, args);
	}

}
