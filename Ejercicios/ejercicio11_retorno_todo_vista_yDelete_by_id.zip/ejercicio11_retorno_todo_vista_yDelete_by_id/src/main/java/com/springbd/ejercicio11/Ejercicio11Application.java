package com.springbd.ejercicio11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio11Application {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio11Application.class, args);
	}

}
