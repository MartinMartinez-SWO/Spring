package com.ejercicio6.ejercicio6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio6Application {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio6Application.class, args);
	}

}
