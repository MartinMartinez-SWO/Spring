package com.ejercicio6.ejercicio6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
