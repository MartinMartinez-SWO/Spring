package com.ejercicio7.ejercicio7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio7Application {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio7Application.class, args);
	}

}
