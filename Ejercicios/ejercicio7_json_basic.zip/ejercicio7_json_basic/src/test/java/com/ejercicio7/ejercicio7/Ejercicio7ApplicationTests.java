package com.ejercicio7.ejercicio7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
