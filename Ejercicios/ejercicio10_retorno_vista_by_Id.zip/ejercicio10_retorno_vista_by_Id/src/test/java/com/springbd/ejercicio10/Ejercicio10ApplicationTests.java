package com.springbd.ejercicio10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
