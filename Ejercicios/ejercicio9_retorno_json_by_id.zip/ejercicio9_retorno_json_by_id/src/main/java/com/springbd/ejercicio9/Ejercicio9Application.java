package com.springbd.ejercicio9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio9Application {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio9Application.class, args);
	}

}
